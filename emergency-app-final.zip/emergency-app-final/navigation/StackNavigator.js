import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import TabNavigator from "./TabNavigator";
import Grocery from "../screens/Grocery";
import Ambulance from "../screens/Ambulance";
import Fire from "../screens/Fire";


const Stack = createStackNavigator();

const StackNavigator = () => {
  return (
    <Stack.Navigator initialRouteName="Search" screenOptions={{ headerShown: false }}>
    <Stack.Screen name="Search" component={TabNavigator} />
    <Stack.Screen name="Grocery" component={Grocery} />
    <Stack.Screen name="Ambulance" component={Ambulance} />
    <Stack.Screen name="Fire" component={Fire} />
    </Stack.Navigator>


    );
};

export default StackNavigator;