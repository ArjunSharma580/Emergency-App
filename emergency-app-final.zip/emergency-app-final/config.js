const firebaseConfig = {
  apiKey: "AIzaSyCJORbjOC78QCwncoeYuG_xFxs0TwRgj0o",
  authDomain: "emergency-app-ccea3.firebaseapp.com",
  projectId: "emergency-app-ccea3",
  storageBucket: "emergency-app-ccea3.appspot.com",
  messagingSenderId: "495115011979",
  appId: "1:495115011979:web:db7f00df93cfd20c2e518e"
};