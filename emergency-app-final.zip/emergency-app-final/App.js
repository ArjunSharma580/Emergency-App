import * as React from 'react';
import { View } from 'react-native';
import { createAppContainer, createSwitchNavigator} from 'react-navigation'; 
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import DrawerNavigator from "./navigation/DrawerNavigator";

import Search from './screens/Search'
import Grocery from './screens/Grocery'
import Ambulance from './screens/Ambulance'
import Fire from './screens/Fire'


//const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <DrawerNavigator/>
    </NavigationContainer>
  );
}

/*<Stack.Navigator initialRouteName="Search" screenOptions={{
headerShown: false
}}>
<Stack.Screen name="Search" component={Search} />
<Stack.Screen name="Geography" component={Geography} />
<Stack.Screen name="Landmarks" component={Landmarks} />
<Stack.Screen name="GenInfo" component={GenInfo} />
</Stack.Navigator>*/