import React, { Component } from 'react';
import { View,
    Text,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    Platform,
    StatusBar,
    ImageBackground,
    TextInput,
    Image } from 'react-native';


export default class Home extends Component {
  constructor(){
  super()
  this.state={
  emailId : '',
  password: ''}}

  /*userLogin = (emailId, password)=>{
    firebase.auth().signInWithEmailAndPassword(emailId, password)
    .then(()=>{
      return Alert.alert("Successfully Login")
    })
    .catch((error)=> {
      var errorCode = error.code;
      var errorMessage = error.message;
      return Alert.alert(errorMessage)
    })
  }*/

render() {
  return (
    <View style={styles.container}>
    <SafeAreaView style={styles.droidSafeArea} />
    <ImageBackground source={require('../assets/Emerbg.jpeg')} style={styles.backgroundImage}>
    <View style={styles.titleBar}>
  
    <Text style={styles.titleText}>APP</Text>
    
</View>

<View>
<Image source={require("../assets/Fire.jpeg")} style={styles.routeImage1}></Image>
    <Image source={require("../assets/grocery.png")} style={styles.routeImage2}></Image>
    <Image source={require("../assets/police.jpeg")} style={styles.routeImage3}></Image>
    <Image source={require("../assets/ambulance.jpeg")} style={styles.routeImage4}></Image>
    </View>
</ImageBackground>
</View>
);}}


  const styles = StyleSheet.create({

  container: {
    flex: 1
  },

  droidSafeArea: {
    marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
  },

  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },

  logoImage:{
    marginTop: 20,
    borderRadius: 20,
    width: 150,
    height: 150,
  },

 

  routeCard: {
    flex: 0.12,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 30,
    marginRight: 30,
    borderRadius: 100
  },

  titleBar: {
    flex: 0.5,
    justifyContent: "center",
    alignItems: "center"
  },

  titleText: {
    marginTop: 100,
    fontSize: 40,
    fontWeight: "bold",
    color: "red"

  },

  descriptionText: {
    marginTop: 100,
    alignItems : 'center',
    fontSize: 20,
    marginLeft: 50,
    color: "tomato"
  },

  routeText: {
    fontSize: 18,
    textDecorationLine: 'underline',
    color: 'white',
    fontFamily: 'comic sans',
    justifyContent: "center",
    alignItems: "center",
    marginTop: 50
  },



  


  routeImage1: {
    position: "absolute",
    top: 5,
    right: 50,
    height: 50,
    width: 70,
    resizeMode: "contain"
  },

    routeImage2: {
    position: "absolute",
    top: 5,
    right: 110,
    height: 50,
    width: 70,
    resizeMode: "contain"
  },

    routeImage3: {
    position: "absolute",
    top: 5,
    right: 170,
    height: 50,
    width: 70,
    resizeMode: "contain"
  },

    routeImage4: {
    position: "absolute",
    top: 5,
    right: 230,
    height: 50,
    width: 70,
    resizeMode: "contain"
  },

  
  });