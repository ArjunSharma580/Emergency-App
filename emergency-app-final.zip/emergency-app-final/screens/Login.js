import React, { Component } from 'react';
import { View,
    Text,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    Platform,
   StatusBar,
    ImageBackground,
    TextInput,
    Image } from 'react-native';

    export default class Login extends Component {
  constructor(){
  super()
  this.state={
  emailId : '',
  password: ''}}

  userLogin = (emailId, password)=>{
    firebase.auth().signInWithEmailAndPassword(emailId, password)
    .then(()=>{
      return Alert.alert("Successfully Login")
    })
    .catch((error)=> {
      var errorCode = error.code;
      var errorMessage = error.message;
      return Alert.alert(errorMessage)
    })
  }

render() {
  return (
<ImageBackground source={require('../assets/Emerbg1.jpeg')} style={styles.backgroundImage}>
    <View style={styles.titleBar}>
    <Text style={styles.titleText}>LOGIN / SIGN UP</Text>
    
 



</View>

<View>
<TextInput style={styles.loginBox} 
 placeholder="abc@gmail.com" 
 placeholderTextColor = "#ffff" 
 keyboardType ='email-address' 
 onChangeText={(text)=>{ this.setState({ emailId: text})}}
/>

<TextInput style={styles.loginBox1}
  secureTextEntry = {true}
  placeholder="password"
  placeholderTextColor = "#ffff"
  onChangeText={(text)=>{ this.setState({ password: text})}}
/>

<TouchableOpacity style={[styles.button,{marginBottom:20, marginTop:10}]}
  onPress = {()=>{this.userLogin(this.state.emailId, this.state.password)}}>
  <Text style={styles.buttonText}>Login</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.routeCard} 
  onPress={() =>this.props.navigation.navigate("AboutApp")}>
  <Text style={styles.routeText}> About App </Text>
</TouchableOpacity>

</View>

</ImageBackground>


);}}

 const styles = StyleSheet.create({

 backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  
  loginBox:{
    width: 300,
    height: 40,
    borderBottomWidth: 1.5,
    borderColor : '#ff8a65',
    fontSize: 20,
    margin:10,
    paddingLeft:10,
    marginTop: 300,
    fontWeight: 'bold',
  },
  loginBox1:{
    width: 300,
    height: 40,
    borderBottomWidth: 1.5,
    borderColor : '#ff8a65',
    fontSize: 20,
    margin:10,
    paddingLeft:10,
    marginTop: 10,
    
  },
    buttonText:{
    color:'#ffff',
    fontWeight: 'bold',
    fontSize:20,
    marginLeft: 120,
  },

   titleText: {
    marginTop: 35,
    marginLeft: 50,
    fontSize: 30,
    fontWeight: "bold",
    color: "#00a7f9"

  },
 
 });