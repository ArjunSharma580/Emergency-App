import React, { Component } from 'react';
import { View,
Text,
StyleSheet,
SafeAreaView,
TouchableOpacity,
Platform,
StatusBar,
ImageBackground,  ScrollView, TextInput, Image,
Dimensions } from 'react-native';

import { RFValue } from "react-native-responsive-fontsize";
import Languages from "./Information";
import { FlatList } from "react-native-gesture-handler";

let customFonts = {
"Bubblegum-Sans": require("../assets/fonts/BubblegumSans-Regular.ttf")
};
let stories = require("./temp_stories.json");

export default class Search extends Component {
  constructor(props) {
  super(props);
  this.state = {
  fontsLoaded: false};}

async _loadFontsAsync() {
  await Font.loadAsync(customFonts);
  this.setState({ fontsLoaded: true });
}

componentDidMount() {
  this._loadFontsAsync();
}

renderItem = ({ item: story }) => {
  return <Languages story={story} navigation={this.props.navigation} />;
};

keyExtractor = (item, index) => index.toString();
  
    render() {
      return (
      <View style={styles.container}>
      <SafeAreaView style={styles.droidSafeArea} />
      <ImageBackground source={require('../assets/AmbulanceBg.jpeg')} style={styles.backgroundImage}>
      <Text style={styles.titleText}>Your Ambulance Is On The  Way...</Text>

      <TouchableOpacity style={[styles.button,{marginBottom:20, marginTop:200}]}
  onPress = {()=>{this.userLogin(this.state.emailId, this.state.password)}}>
  <Text style={styles.buttonText}>Tap Here To Share Your Location</Text>
</TouchableOpacity>
      <View style={styles.titleBar}>
     
      </View>



     
      </ImageBackground>
      </View> )}}

const styles = StyleSheet.create({
container: {
  flex: 1
},

droidSafeArea: {
  marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
},

backgroundImage: {
  flex: 1,
  resizeMode: 'cover',
},

routeCard: {
  flex: 0.12,
  justifyContent: "center",
  alignItems: "center",
  margin: 10,
  marginLeft: 30,
  marginRight: 30,
  borderRadius: 100,
  backgroundColor: "white"
},

titleBar: {
  flex: 0.5,
  justifyContent: "center",
  alignItems: "center"
},

titleText: {
  marginTop : 100,
  fontSize: 40,
  fontWeight: "bold",
  color: "white"
},

descriptionText: {
  fontSize: 20,
  marginLeft : 50,
  color: "black"
},

routeText: {
  fontSize: 25,
  fontWeight: "bold",
  color: 'black',
  justifyContent: "center",
  alignItems: "center"
},

routeImage: {
  position: "absolute",
  top: 4,
  right: -9,
  height: 40,
  width: 80,
  resizeMode: "contain"
},

  bar:{
    marginTop: 30,
    width: '80%',
    alignSelf: 'center',
    height: 40,
    textAlign: 'center',
    borderWidth: 4,
    borderColor: 'black',
    outline: 'none',
    backgroundColor: 'white',
    fontFamily: 'Amerika',
    fontSize: 30,
    borderRadius: 100
  },

searchText: {
    textAlign: 'center',
    fontSize: 25,
    alignSelf: 'center',
    fontWeight: 'bold',
    color:'black'
  },

  searchButton: {
    width: '40%',
    height: 50,
    alignSelf: 'center',
    padding: 3,
    margin: 10,
    marginTop: 20,
    borderWidth: 4,
    borderRadius: 20,
    borderColor: 'black',
    backgroundColor: ''
  },
  
});

